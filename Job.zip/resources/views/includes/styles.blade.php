    <!-- CSS Global Compulsory (Do not remove)-->
    <link rel="stylesheet" href="/../libraries/css/font-awesome/all.min.css" />
    <link rel="stylesheet" href="/../libraries/css/flaticon/flaticon.css" />
    <link rel="stylesheet" href="/../libraries/css/bootstrap/bootstrap.min.css" />

    <!-- Page CSS Implementing Plugins (Remove the plugin CSS here if site does not use that feature)-->
    <link rel="stylesheet" href="/../libraries/css/select2/select2.css" />
    <link rel="stylesheet" href="/../libraries/css/owl-carousel/owl.carousel.min.css" />

    <!-- Template Style -->
    <link rel="stylesheet" href="/../libraries/css/style.css" />
