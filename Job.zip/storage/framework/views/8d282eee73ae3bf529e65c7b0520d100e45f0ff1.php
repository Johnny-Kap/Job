<?php $__env->startSection('content'); ?>
    <!--=================================
            banner -->
    <div class="candidate-banner bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="candidate-list bg-light">
                        <div class="candidate-list-image">
                            <?php if($profil_detail->image == null): ?>
                                <img class="img-fluid" src="\..\libraries\images\no-profile-pic-icon-0.jpg" alt="">
                            <?php else: ?>
                                <img class="img-fluid" style="width: 110px; height:90px;" src="<?php echo e(Storage::url($profil_detail->image)); ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="candidate-list-details">
                            <div class="candidate-list-info">
                                <div class="candidate-list-title">
                                    <h5 class="mb-0"><?php echo e($profil_detail->prenom); ?> <?php echo e($profil_detail->name); ?></h5>
                                </div>
                                <div class="candidate-list-option">
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-filter pe-1"></i><?php echo e($profil_detail->secteurs->intitule); ?></li>
                                        <li><i class="fas fa-map-marker-alt pe-1"></i>
                                            <?php if($profil_detail->Adresse == null): ?>
                                                Aucune adresse
                                            <?php else: ?>
                                                <?php echo e($profil_detail->Adresse); ?>

                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--=================================
                  banner -->

    <section class="space-pb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="sticky-top secondary-menu-sticky-top">
                        <div class="secondary-menu">
                            <ul>
                                <li><a href="#about"> About </a></li>
                                <li><a href="#informations"> Informations personnelles </a></li>
                                <li><a href="#education"> Education </a></li>
                                <li><a href="#experience"> Work Experience </a></li>
                                <li><a href="#skill"> professional Skill </a></li>
                                <li><a href="#langues"> Langues </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 mb-4 mb-lg-0">
                    <div class="jobber-candidate-detail">
                        
                        
                        <hr class="my-4 my-md-5">
                        <div id="about">
                            <h5 class="mb-3">About Me</h5>
                            <div class="border p-3">
                                <div class="row">
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-account"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Name:</label>
                                                <span class="d-block fw-bold text-dark"><?php echo e($profil_detail->name); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-account"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Prénom:</label>
                                                <span class="d-block fw-bold text-dark"><?php echo e($profil_detail->prenom); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-account"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Email:</label>
                                                <span class="d-block fw-bold text-dark"><?php echo e($profil_detail->email); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-curriculum"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Secteur:</label>
                                                <span
                                                    class="d-block fw-bold text-dark"><?php echo e($profil_detail->secteurs->intitule); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-contact"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Phone :</label>
                                                <span class="d-block fw-bold text-dark"><?php echo e($profil_detail->tel); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-appointment"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Date Of Birth :</label>
                                                <span class="d-block fw-bold text-dark">
                                                    <?php if($profil_detail->date_naiss == null): ?>
                                                        Aucune date
                                                    <?php else: ?>
                                                        <?php echo e($profil_detail->date_naiss); ?>

                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-map"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Address :</label>
                                                <span class="d-block fw-bold text-dark">
                                                    <?php if($profil_detail->adresse == null): ?>
                                                        Aucune adresse
                                                    <?php else: ?>
                                                        <?php echo e($profil_detail->adresse); ?>

                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 mb-4">
                                        <div class="d-flex">
                                            <i class="font-xll text-primary align-self-center flaticon-man"></i>
                                            <div class="feature-info-content ps-3">
                                                <label class="mb-0">Sex :</label>
                                                <span
                                                    class="d-block fw-bold text-dark"><?php echo e($profil_detail->genres->titre); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-4 mt-sm-5">
                                <b>Description du profil :</b>
                                <?php if($profil_detail->description == null): ?>
                                    Aucune description
                                <?php else: ?>
                                    <?php echo e($profil_detail->description); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        <hr class="my-4 my-md-5">
                        <div id="informations">
                            <h5 class="mb-3">Informations personnelles</h5>
                            <div class="jobber-candidate-timeline">
                                <div class="jobber-timeline-icon">
                                    <i class="fas fa-trophy"></i>
                                </div>
                                <div class="jobber-timeline-item mb-0">
                                    <div class="jobber-timeline-cricle">
                                        <i class="far fa-circle"></i>
                                    </div>
                                    <div class="jobber-timeline-info">
                                        <span class="jobber-timeline-time">High level education :
                                            <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($item->high_level_education); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="jobber-timeline-item mb-0">
                                    <div class="jobber-timeline-cricle">
                                        <i class="far fa-circle"></i>
                                    </div>
                                    <div class="jobber-timeline-info">
                                        <span class="jobber-timeline-time">Nombre total d'experience :
                                            <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($item->total_year_experience); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="my-4 my-md-5">
                        <div id="experience">
                            <h5 class="mb-3">Work & Experience</h5>
                            <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="jobber-candidate-timeline">
                                    <div class="jobber-timeline-icon">
                                        <i class="fas fa-briefcase"></i>
                                    </div>
                                    <div class="jobber-timeline-item">
                                        <div class="jobber-timeline-cricle">
                                            <i class="far fa-circle"></i>
                                        </div>
                                        <div class="jobber-timeline-info">
                                            <span class="jobber-timeline-time"><?php echo e($item->date_debut); ?> <b>to</b>
                                                <?php echo e($item->date_fin); ?></span>
                                            <h6 class="mb-2"><?php echo e($item->poste); ?></h6>
                                            <span>- <?php echo e($item->nom_entreprise); ?></span>
                                            <p class="mt-2"><?php echo e($item->description); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr class="my-4 my-md-5">
                        <div id="education">
                            <h5 class="mb-3">Education</h5>
                            <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="jobber-candidate-timeline">
                                    <div class="jobber-timeline-icon">
                                        <i class="fas fa-graduation-cap"></i>
                                    </div>
                                    <div class="jobber-timeline-item">
                                        <div class="jobber-timeline-cricle">
                                            <i class="far fa-circle"></i>
                                        </div>
                                        <div class="jobber-timeline-info">
                                            <span class="jobber-timeline-time"><?php echo e($item->date_debut); ?> -
                                                <?php echo e($item->date_fin); ?></span>
                                            <h6 class="mb-2"><?php echo e($item->nom_diplome); ?></h6>
                                            <span>- <?php echo e($item->ecole); ?></span>
                                            <p class="mt-2"><?php echo e($item->description); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr class="my-4 my-md-5">
                        <div id="skill">
                            <h5 class="mb-3">Compétences</h5>
                            <?php $__currentLoopData = $competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="jobber-candidate-timeline">
                                    <div class="jobber-timeline-icon">
                                        <i class="fas fa-trophy"></i>
                                    </div>
                                    <div class="jobber-timeline-item mb-0">
                                        <div class="jobber-timeline-cricle">
                                            <i class="far fa-circle"></i>
                                        </div>
                                        <div class="jobber-timeline-info">
                                            <span class="jobber-timeline-time"><?php echo e($item->intitule); ?> --
                                                <?php echo e($item->niveau); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr class="my-4 my-md-5">
                        <div id="langues">
                            <h5 class="mb-3">Langues</h5>
                            <?php $__currentLoopData = $langues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="jobber-candidate-timeline">
                                    <div class="jobber-timeline-icon">
                                        <i class="fas fa-trophy"></i>
                                    </div>
                                    <div class="jobber-timeline-item mb-0">
                                        <div class="jobber-timeline-cricle">
                                            <i class="far fa-circle"></i>
                                        </div>
                                        <div class="jobber-timeline-info">
                                            <span class="jobber-timeline-time"><?php echo e($item->intitule); ?> --
                                                <?php echo e($item->niveau); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-employer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Job\resources\views/entreprise/profil-detail.blade.php ENDPATH**/ ?>