<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php

    use App\Models\Genre;
    use App\Models\Secteur;

    $genres = Genre::all();

    $secteurs = Secteur::all();
?>

<!--=================================
inner banner -->
<div class="header-inner bg-light text-center">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="text-primary">Register</h2>
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="index.html"> Home </a></li>
                    <li class="breadcrumb-item active"> <i class="fas fa-chevron-right"></i> <span> Register </span></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--=================================
  inner banner -->

<!--=================================
  Register -->
<section class="space-ptb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-10 col-md-12">
                <div class="login-register">
                    <div class="section-title">
                        <h4 class="text-center">Create Your Account</h4>
                    </div>
                    <fieldset>
                        <legend class="px-2">Choose your Account Type</legend>
                        <ul class="nav nav-tabs nav-tabs-border d-flex" role="tablist">
                            <li class="nav-item me-4">
                                <a class="nav-link active" data-bs-toggle="tab" href="#candidate" role="tab">
                                    <div class="d-flex">
                                        <div class="tab-icon">
                                            <i class="flaticon-users"></i>
                                        </div>
                                        <div class="ms-3">
                                            <h6 class="mb-0">Candidate</h6>
                                            <p class="mb-0">I want to discover companies.</p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item ms-auto">
                                <a class="nav-link" data-bs-toggle="tab" href="#employer" role="tab">
                                    <div class="d-flex">
                                        <div class="tab-icon">
                                            <i class="flaticon-suitcase"></i>
                                        </div>
                                        <div class="ms-3">
                                            <h6 class="mb-0">Employer</h6>
                                            <p class="mb-0">I want to attract the best talent.</p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </fieldset>
                    <div class="tab-content">
                        <div class="tab-pane active" id="candidate" role="tabpanel">
                            <form class="mt-4" method="post" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3 col-md-12 select-border">
                                        <label class="form-label" for="genre">Vous etes :</label>
                                        <select class="form-control basic-select" name="is_enterprise">
                                                <option value="0" selected="selected">Un candidat</option>
                                        </select>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="Username">Nom *</label>
                                        <input type="text" id="name"
                                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                            value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="Username">Prénom</label>
                                        <input type="text" id="name"
                                            class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prenom"
                                            value="<?php echo e(old('prenom')); ?>" required>

                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3 col-md-12">
                                        <label class="form-label">Email Address *</label>
                                        <input type="text" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label">Password *</label>
                                        <input type="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="password2">Confirm Password *</label>
                                        <input type="password" id="password-confirm" name="password_confirmation" required autocomplete="new-password" class="form-control">
                                    </div>
                                    <div class="mb-3 col-6">
                                        <label class="form-label" for="phone">Phone:</label>
                                        <input type="text" id="tel" name="tel" class="form-control">
                                    </div>
                                    <div class="mb-3 col-md-6 datetimepickers">
                                        <label class="form-label">Date de naissance</label>
                                        <div class="input-group date" id="datetimepicker-01"
                                            data-target-input="nearest">
                                            <input type="text"
                                                class="form-control datetimepicker-input"
                                                value="08/11/1999" name="date_naiss"
                                                data-target="#datetimepicker-01">
                                            <div class="input-group-append d-flex"
                                                data-target="#datetimepicker-01"
                                                data-toggle="datetimepicker">
                                                <div class="input-group-text"><i
                                                        class="far fa-calendar-alt"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12 select-border">
                                        <label class="form-label" for="genre">Select gender *:</label>
                                        <select class="form-control basic-select" name="genre">
                                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" selected="selected"><?php echo e($item->titre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3 col-md-12 select-border">
                                        <label class="form-label" for="sector">Select Sector *:</label>
                                        <select class="form-control basic-select" name="secteur">
                                            <?php $__currentLoopData = $secteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" selected="selected"><?php echo e($item->intitule); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-3 col-12">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="Remember-02">
                                            <label class="form-check-label" for="Remember-02">
                                                you accept our Terms and Conditions and Privacy Policy
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-primary d-block">
                                            Register
                                        </button>
                                    </div>
                                    <div class="col-md-6 text-md-end mt-2 text-center">
                                        <p>Already registered? <a href="<?php echo e(route('login')); ?>"> Sign in here</a></p>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="employer" role="tabpanel">
                            <form class="mt-4" method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3 col-md-12 select-border">
                                        <label class="form-label" for="genre">Vous etes :</label>
                                        <select class="form-control basic-select" name="is_enterprise">
                                                <option value="1" selected="selected">Une entreprise</option>
                                        </select>
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label">Nom de l'entreprise *</label>
                                        <input type="text" name="name" class="form-control" id="Username">
                                    </div>
                                    
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label">Email Address *</label>
                                        <input type="email" name="email" class="form-control" id="email">
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label">Password *</label>
                                        <input type="password" name="password" class="form-control" id="Password">
                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <label class="form-label" for="password2">Confirm Password *</label>
                                        <input type="password" name="password_confirmation" class="form-control" id="password2">
                                    </div>
                                    <div class="mb-3 col-6">
                                        <label class="form-label" for="phone">Phone</label>
                                        <input type="text" class="form-control" name="tel" id="phone">
                                    </div>
                                    <div class="mb-3 col-md-6 datetimepickers">
                                        <label class="form-label">Date de création</label>
                                        <div class="input-group date" id="datetimepicker-01"
                                            data-target-input="nearest">
                                            <input type="text"
                                                class="form-control datetimepicker-input"
                                                value="08/11/1999" name="date_naiss"
                                                data-target="#datetimepicker-01">
                                            <div class="input-group-append d-flex"
                                                data-target="#datetimepicker-01"
                                                data-toggle="datetimepicker">
                                                <div class="input-group-text"><i
                                                        class="far fa-calendar-alt"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3 col-md-12 select-border">
                                        <label class="form-label" for="sector">Select Sector *:</label>
                                        <select class="form-control basic-select" name="secteur">
                                            <?php $__currentLoopData = $secteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" selected="selected"><?php echo e($item->intitule); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3 col-12 mt-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="accepts-02">
                                            <label class="form-check-label" for="accepts-02">
                                                you accept our Terms and Conditions and Privacy Policy
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-primary d-block">Enregistrer</button>
                                    </div>
                                    <div class="col-md-6 text-md-end mt-2 text-center">
                                        <a href="<?php echo e(route('login')); ?>">Already have an account?</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--=================================
  Register -->

<?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\Job\resources\views/auth/register.blade.php ENDPATH**/ ?>