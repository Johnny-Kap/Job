 <!-- JS Global Compulsory (Do not remove)-->
 <script src="../libraries/js/jquery-3.6.0.min.js"></script>
 <script src="../libraries/js/popper/popper.min.js"></script>
 <script src="../libraries/js/bootstrap/bootstrap.min.js"></script>

 <!-- Page JS Implementing Plugins (Remove the plugin script here if site does not use that feature)-->
 <script src="../libraries/js/jquery.appear.js"></script>
 <script src="../libraries/js/counter/jquery.countTo.js"></script>
 <script src="../libraries/js/owl-carousel/owl-carousel.min.js"></script>

 <!-- Template Scripts (Do not remove)-->
 <script src="../libraries/js/custom.js"></script>

   <!-- Page JS Implementing Plugins (Remove the plugin script here if site does not use that feature)-->
   <script src="../libraries/js/select2/select2.full.js"></script>
   <script src="../libraries/js/datetimepicker/moment.min.js"></script>
   <script src="../libraries/js/datetimepicker/datetimepicker.min.js"></script>
<?php /**PATH C:\wamp64\www\Job\resources\views/includes/scripts.blade.php ENDPATH**/ ?>