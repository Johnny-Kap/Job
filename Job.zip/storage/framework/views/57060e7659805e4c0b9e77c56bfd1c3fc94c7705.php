<?php $__env->startSection('content'); ?>
    <!--=================================
                                            inner banner -->
    <div class="header-inner bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="candidates-user-info">
                        <div class="jobber-user-info">
                            <div class="profile-avatar">
                                <?php if(Auth::user()->image == null): ?>
                                    <img class="img-fluid" src="libraries\images\no-profile-pic-icon-0.jpg" alt="">
                                <?php else: ?>
                                    <img class="img-fluid" src="<?php echo e(Storage::url(Auth::user()->image)); ?>" alt="">
                                <?php endif; ?>
                                <i class="fas fa-pencil-alt"></i>
                            </div>
                            <div class="profile-avatar-info ms-4">
                                <h3><?php echo e(Auth::user()->prenom); ?> <?php echo e(Auth::user()->name); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br>
    <!--=================================
                                                                                  inner banner -->
    <!--=================================
        Manage Jobs -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="user-dashboard-info-box mb-0">
                        <div class="row mb-4">
                            <div class="col-md-7 col-sm-5 d-flex align-items-center">
                                <div class="section-title-02 mb-0 ">
                                    <h4 class="mb-0">Manage Jobs</h4>
                                </div>
                            </div>
                            <div class="col-md-5 col-sm-7 mt-3 mt-sm-0">
                                
                            </div>
                        </div>
                        <div class="user-dashboard-table table-responsive">
                            <table class="table table-bordered">
                                <thead class="bg-light">
                                    <tr>
                                        <th scope="col">Job Title</th>
                                        <th scope="col">Applications</th>
                                        <th scope="col">Date de candidature</th>
                                        <th scope="col">Validation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $apply_job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($item->jobs->titre); ?>

                                            <p class="mb-1 mt-2">Expiry: <?php echo e($item->jobs->dateline); ?></p>
                                            <p class="mb-0">Address: <?php echo e($item->jobs->adresse); ?></p>
                                        </th>
                                        <td>Soumis</td>
                                        <td><?php echo e($item->created_at->format('d-m-y')); ?></td>
                                        <td>
                                            <?php if($item->validated == 1): ?>
                                            Validé
                                            <?php else: ?>
                                            En attente
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-12 text-center">
                                <?php echo e($apply_job->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================================
          Manage Jobs -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Job\resources\views/candidat/gestion-emplois.blade.php ENDPATH**/ ?>