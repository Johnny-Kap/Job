<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="block h1" width="1em" height="1em" role="img" fill="currentColor" path="table" componentName="orchid-icon">
    <path d="M9,0H1A1,1,0,0,0,0,1V9a1,1,0,0,0,1,1H9a1,1,0,0,0,1-1V1A1,1,0,0,0,9,0ZM8,8H2V2H8Z"></path>
    <path d="M20,0H12a1,1,0,0,0-1,1V9a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1V1A1,1,0,0,0,20,0ZM19,8H13V2h6Z"></path>
    <path d="M31,0H23a1,1,0,0,0-1,1V9a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1V1A1,1,0,0,0,31,0ZM30,8H24V2h6Z"></path>
    <path d="M9,11H1a1,1,0,0,0-1,1v8a1,1,0,0,0,1,1H9a1,1,0,0,0,1-1V12A1,1,0,0,0,9,11ZM8,19H2V13H8Z"></path>
    <path d="M20,11H12a1,1,0,0,0-1,1v8a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1V12A1,1,0,0,0,20,11Zm-1,8H13V13h6Z"></path>
    <path d="M31,11H23a1,1,0,0,0-1,1v8a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1V12A1,1,0,0,0,31,11Zm-1,8H24V13h6Z"></path>
    <path d="M9,22H1a1,1,0,0,0-1,1v8a1,1,0,0,0,1,1H9a1,1,0,0,0,1-1V23A1,1,0,0,0,9,22ZM8,30H2V24H8Z"></path>
    <path d="M20,22H12a1,1,0,0,0-1,1v8a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1V23A1,1,0,0,0,20,22Zm-1,8H13V24h6Z"></path>
    <path d="M31,22H23a1,1,0,0,0-1,1v8a1,1,0,0,0,1,1h8a1,1,0,0,0,1-1V23A1,1,0,0,0,31,22Zm-1,8H24V24h6Z"></path>
</svg>
<?php /**PATH C:\wamp64\www\Job\storage\framework\views/cb5eba5f8f910e0da137196e5599451890c6c3a8.blade.php ENDPATH**/ ?>