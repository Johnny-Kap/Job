<?php $__env->startSection('content'); ?>
    <!--=================================
                                            inner banner -->
    <div class="header-inner bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="candidates-user-info">
                        <div class="jobber-user-info">
                            <div class="profile-avatar">
                                <?php if(Auth::user()->image == null): ?>
                                    <img class="img-fluid" src="\..\libraries\images\no-profile-pic-icon-0.jpg" alt="">
                                <?php else: ?>
                                    <img class="img-fluid" src="<?php echo e(Storage::url(Auth::user()->image)); ?>" alt="">
                                <?php endif; ?>
                                <i class="fas fa-pencil-alt"></i>
                            </div>
                            <div class="profile-avatar-info ms-4">
                                <h3><?php echo e(Auth::user()->name); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br>
    <!--=================================
                                                                                  inner banner -->
    <!--=================================
        Manage Jobs -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="user-dashboard-info-box mb-0">
                        <div class="row mb-4">
                            <div class="col-md-7 col-sm-5 d-flex align-items-center">
                                <div class="section-title-02 mb-0 ">
                                    <h4 class="mb-0">Manage Candidature</h4>
                                </div>
                            </div>
                            <div class="col-md-5 col-sm-7 mt-3 mt-sm-0">
                                
                            </div>
                        </div>
                        <div class="user-dashboard-table table-responsive">
                            <table class="table table-bordered">
                                <thead class="bg-light">
                                    <tr>
                                        <th scope="col">Job Title</th>
                                        <th scope="col">Nom du candidat</th>
                                        <th scope="col">Prénom du candidat</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Téléphone</th>
                                        <th scope="col">Date de candidature</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $my_candidat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($item->jobs->titre); ?></th>
                                        <td><?php echo e($item->users->name); ?></td>
                                        <td><?php echo e($item->users->prenom); ?></td>
                                        <td><?php echo e($item->users->email); ?></td>
                                        <td><?php echo e($item->users->tel); ?></td>
                                        <td><?php echo e($item->created_at->format('d-m-y')); ?></td>
                                        <td>
                                            <ul class="list-unstyled mb-0 d-flex">
                                                <li><a href="<?php echo e(route('entreprise.profil.detail', ['id' => $item->user_id])); ?>" class="text-primary" data-bs-toggle="tooltip" title="Voir le profil"><i class="far fa-eye"></i></a></li>
                                                
                                            </ul>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-12 text-center">
                                <?php echo e($my_candidat->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================================
          Manage Jobs -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins-employer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Job\resources\views/entreprise/gestion-candidature.blade.php ENDPATH**/ ?>